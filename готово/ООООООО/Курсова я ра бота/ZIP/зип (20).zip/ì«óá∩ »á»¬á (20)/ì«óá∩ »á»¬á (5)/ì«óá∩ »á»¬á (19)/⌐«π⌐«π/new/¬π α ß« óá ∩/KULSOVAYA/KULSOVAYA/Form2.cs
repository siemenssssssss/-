﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO; // Для File и Path

namespace KULSOVAYA
{
    public partial class Form2 : Form
    {
        private string connectionString; // Объявление без инициализации

        public Form2()
        {

            InitializeComponent();

            string databasePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "komandirovki.mdb");
            if (!File.Exists(databasePath))
            {
                MessageBox.Show($"Файл базы данных не найден: {databasePath}");
                return;
            }

            connectionString = $"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={databasePath};";


            // Установите connectionString для каждого TableAdapter:
            командировкиTableAdapter.Connection.ConnectionString = connectionString;
            сотрудникиTableAdapter.Connection.ConnectionString = connectionString;
            населенный_пунктTableAdapter.Connection.ConnectionString = connectionString;
            расходыTableAdapter.Connection.ConnectionString = connectionString;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                this.командировкиTableAdapter.Fill(this.komandirovkiDataSet.Командировки);
                this.сотрудникиTableAdapter.Fill(this.komandirovkiDataSet.Сотрудники);
                this.населенный_пунктTableAdapter.Fill(this.komandirovkiDataSet.Населенный_пункт);
                this.расходыTableAdapter.Fill(this.komandirovkiDataSet.Расходы);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }
        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string s = населенныйпунктBindingSource.Filter = "Регион Like \'" + textBox1.Text + "*\'" + "or Название Like \'" + textBox1.Text + "*\'" + "or Суточные Like \'" + textBox1.Text + "*\'";
            населенныйпунктBindingSource.Filter = s;
        }

        private void добавлениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string query = "INSERT INTO Населенный_пункт (Название, Суточные, Регион) VALUES (@Название, @Суточные, @Регион)";

            using (OleDbConnection dbConnection = new OleDbConnection(connectionString))
            {
                try
                {
                    dbConnection.Open();
                    using (OleDbCommand command = new OleDbCommand(query, dbConnection))
                    {
                        // Убрали int.TryParse
                        if (!string.IsNullOrEmpty(textBox2.Text)) // Проверка на пустое значение
                        {
                            command.Parameters.AddWithValue("@Название", textBox2.Text); // Текстовое значение напрямую
                            command.Parameters.AddWithValue("@Суточные", textBox5.Text);
                            command.Parameters.AddWithValue("@Регион", textBox6.Text);


                            int n = command.ExecuteNonQuery();
                            if (n > 0)
                            {
                                MessageBox.Show("Запись добавлена успешно!");
                                tabControl1.SelectedIndex = 0; // Переключение на первую вкладку
                                this.населенный_пунктTableAdapter.Fill(this.komandirovkiDataSet.Населенный_пункт); // Обновление DataGridView
                                textBox2.Clear(); // Очистка полей ввода
                                textBox5.Clear();
                                textBox6.Clear();

                                // Другой код, который вы хотите выполнить после успешной вставки, 
                            }
                            else
                            {
                                MessageBox.Show("Не удалось добавить запись.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ошибка: Поле 'Название' не должно быть пустым.");
                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении данных: {ex.Message}");
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string s = сотрудникиBindingSource.Filter = "ФИО Like \'" + textBox3.Text + "*\'" + "or Должность Like \'" + textBox3.Text + "*\'" + "or Отдел Like \'" + textBox3.Text + "*\'";
            сотрудникиBindingSource.Filter = s;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Сотрудники (ФИО, Должность, Отдел, Контактный_телефон, Дата_рожд) VALUES ( @ФИО, @Должность, @Отдел, @Контактный_телефон, @Дата_рожд)";

            using (OleDbConnection dbConnection = new OleDbConnection(connectionString))
            {
                try
                {
                    dbConnection.Open();
                    using (OleDbCommand command = new OleDbCommand(query, dbConnection))
                    {
                        // Проверка на пустые значения
                        if (
                            !string.IsNullOrEmpty(textBox7.Text) &&
                            !string.IsNullOrEmpty(textBox8.Text) &&
                            !string.IsNullOrEmpty(textBox9.Text) &&
                            !string.IsNullOrEmpty(textBox10.Text) &&
                            !string.IsNullOrEmpty(textBox11.Text)) // Проверка на пустое значение
                        {
                            
                            command.Parameters.AddWithValue("@ФИО", textBox7.Text);
                            command.Parameters.AddWithValue("@Должность", textBox8.Text);
                            command.Parameters.AddWithValue("@Отдел", textBox9.Text);
                            command.Parameters.AddWithValue("@Контактный_телефон", textBox10.Text);

                            // Преобразование текста в DateTime для даты рождения
                            if (DateTime.TryParse(textBox11.Text, out DateTime датаРожд))
                            {
                                command.Parameters.AddWithValue("@Дата_рожд", датаРожд);
                            }
                            else
                            {
                                MessageBox.Show("Ошибка: Неверный формат даты.");
                                return;
                            }

                            int n = command.ExecuteNonQuery();
                            if (n > 0)
                            {
                                MessageBox.Show("Запись добавлена успешно!");
                                tabControl1.SelectedIndex = 0; // Переключение на первую вкладку
                                this.сотрудникиTableAdapter.Fill(this.komandirovkiDataSet.Сотрудники); // Обновление DataGridView
                                

                                // Другой код, который вы хотите выполнить после успешной вставки,
                            }
                            else
                            {
                                MessageBox.Show("Не удалось добавить запись.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Ошибка: Все поля должны быть заполнены.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при добавлении данных: {ex.Message}");
                }
            }
        }

        private void удалениеToolStripMenuItem_Click(object sender, EventArgs e)
        {

            // Проверяем, выбрана ли строка
            if (dataGridView3.SelectedRows.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите запись для удаления.");
                return;
            }

            // Получаем ID из выбранной строки (первая ячейка - Cells[0])
            // Добавлена проверка на DBNull.Value
            object cellValue = dataGridView3.SelectedRows[0].Cells[0].Value;

            if (cellValue == null || cellValue == DBNull.Value)
            {
                MessageBox.Show("Пожалуйста, выберите запись, в которой заполнен ID.");
                return;
            }

            string idValue = cellValue.ToString().Trim();

            // Пробуем преобразовать значение в число
            if (int.TryParse(idValue, out int selectedId))
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить запись?", "Подтверждение", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    string query = "DELETE FROM [Населенный_пункт] WHERE Код_Населенного_пункта = @КодНаселенногоПункта"; // Имя таблицы в скобках

                    using (OleDbConnection dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=komandirovki.mdb")) // Уточните строку подключения
                    {
                        try
                        {
                            dbConnection.Open();
                            using (OleDbCommand command = new OleDbCommand(query, dbConnection))
                            {
                                // Добавляем параметр с ID
                                command.Parameters.AddWithValue("@КодНаселенногоПункта", selectedId);
                                int rowsAffected = command.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Запись удалена успешно!");
                                    // Обновляем данные в DataGridView
                                    this.населенный_пунктTableAdapter.Fill(this.komandirovkiDataSet.Населенный_пункт);
                                }
                                else
                                {
                                    MessageBox.Show("Не удалось удалить запись. Проверьте, существует ли она.");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Удаление невозможно!");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show($"Неверный формат ID: '{idValue}'. Выберите запись для удаления."); // Вывод значения для отладки
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button3_Click(object sender, EventArgs e)
        {


        }

        private void редактированиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // 1. Проверка выбора строки
            if (dataGridView3.SelectedRows == null || dataGridView3.SelectedRows.Count == 0)
            {
                MessageBox.Show("Пожалуйста, выберите запись для редактирования.");
                return;
            }

            // 2. Получение индекса выбранной строки
            int rowIndex = dataGridView3.SelectedRows[0].Index;

            // 3. Проверка наличия необходимых столбцов
            string[] columnNames = { "Название", "Регион", "Суточные" };
            foreach (string columnName in columnNames)
            {
                if (!dataGridView3.Columns.Contains(columnName))
                {
                    MessageBox.Show($"Столбец '{columnName}' не найден в DataGridView.");
                    return;
                }
            }

            // 4. Получение текущих значений для редактирования (с проверками на null)
            string текущееНазвание = dataGridView3.Rows[rowIndex].Cells["Название"]?.Value?.ToString() ?? "";
            string текущийРегион = dataGridView3.Rows[rowIndex].Cells["Регион"]?.Value?.ToString() ?? "";
            string суточныеStr = dataGridView3.Rows[rowIndex].Cells["Суточные"]?.Value?.ToString() ?? "";



            if (!decimal.TryParse(суточныеStr, out decimal текущиеСуточные))
            {
                MessageBox.Show($"Неверный формат суточных: '{суточныеStr}'.");
                return;
            }

            // 5. Открытие формы редактирования и передача значений
            Form4 form4 = new Form4(rowIndex, текущееНазвание, текущийРегион, текущиеСуточные); // Передаем rowIndex вместо ID

            if (form4.ShowDialog() == DialogResult.OK)
            {
                // 6. Обновление данных в DataGridView после редактирования 
                dataGridView3.Rows[rowIndex].Cells["Название"].Value = form4.Название;
                dataGridView3.Rows[rowIndex].Cells["Регион"].Value = form4.Регион;
                dataGridView3.Rows[rowIndex].Cells["Суточные"].Value = form4.Суточные;

                // Если DataGridView привязан к DataTable, нужно обновить и DataTable:
                if (dataGridView3.DataSource is DataTable dt)
                {
                    dt.Rows[rowIndex]["Название"] = form4.Название;
                    dt.Rows[rowIndex]["Регион"] = form4.Регион;
                    dt.Rows[rowIndex]["Суточные"] = form4.Суточные;
                }

            }
        }
        

                private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            panel2.Visible = checkBox1.Checked;
        }
    }
}
        
    
  
    

