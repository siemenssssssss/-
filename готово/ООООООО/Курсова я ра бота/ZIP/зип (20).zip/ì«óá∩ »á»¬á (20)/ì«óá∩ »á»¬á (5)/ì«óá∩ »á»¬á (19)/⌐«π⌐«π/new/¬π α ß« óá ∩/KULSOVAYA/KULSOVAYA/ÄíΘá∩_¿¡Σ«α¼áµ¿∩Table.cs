﻿using System.Data;

namespace KULSOVAYA
{
    internal class Общая_информацияTable
    {
        public DataView DefaultView { get; internal set; }
    }
}