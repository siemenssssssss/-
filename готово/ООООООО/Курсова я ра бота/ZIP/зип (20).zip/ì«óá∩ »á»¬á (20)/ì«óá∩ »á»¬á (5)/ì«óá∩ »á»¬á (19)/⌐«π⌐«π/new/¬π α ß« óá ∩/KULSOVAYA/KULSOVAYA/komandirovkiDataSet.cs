﻿namespace KULSOVAYA
{


    partial class komandirovkiDataSet
    {
        partial class Населенный_пунктDataTable
        {
        }

        partial class Общая_информацияDataTable
        {
        }
    }
}
