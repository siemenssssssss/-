﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KULSOVAYA
{
    public partial class Form4 : Form
    {
        private int _id;
        private string _название;
        private string название;
        private int id;
        private int selectedId;
        private string текущееНазвание;

        public Form4(int selectedId, string текущееНазвание)
        {
            this.selectedId = selectedId;
            this.текущееНазвание = текущееНазвание;
        }

        public Form4(int id, string название, string регион, decimal суточные) // Только конструктор с параметрами
        {
            InitializeComponent();
            _id = id;
            _название = название;
            textBox1.Text = _название;
        }

        public string Название { get; internal set; }
        public string Регион { get; internal set; }
        public decimal Суточные { get; internal set; }

        private void button1_Click(object sender, EventArgs e)
        {
            string новоеНазвание = textBox1.Text;
            string новыеСуточные = textBox3.Text;
            string новыеРегионы = textBox4.Text;


            // Проверка на числовое значение для "новыеСуточные"
            if (!decimal.TryParse(новыеСуточные, out decimal суточные))
            {
                MessageBox.Show("Значение для 'Суточные' должно быть числом.");
                return;
            }




            string query = "UPDATE Населенный_пункт SET Название = @НовоеНазвание, Суточные = @НовыеСуточные, Регион = @НовыеРегионы WHERE Код_Населенного_пункта = @КодНаселенногоПункта";

            using (OleDbConnection dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=komandirovki.mdb"))
            {
                try
                {
                    dbConnection.Open();
                    using (OleDbCommand command = new OleDbCommand(query, dbConnection))
                    {
                        command.Parameters.AddWithValue("@НовоеНазвание", новоеНазвание);
                        command.Parameters.AddWithValue("@НовыеСуточные", суточные); // Используем преобразованное значение
                        command.Parameters.AddWithValue("@НовыеРегионы", новыеРегионы);
                        command.Parameters.AddWithValue("@КодНаселенногоПункта", _id);


                        command.ExecuteNonQuery();
                        MessageBox.Show("Запись обновлена успешно!");
                        DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string новоеФИО = textBoxФИО.Text;
            string новаяДолжность = textBoxДолжность.Text;
            string новыйОтдел = textBoxОтдел.Text;
            string новыйКонтактныйТелефон = textBoxКонтактныйТелефон.Text;
            string новаяДатаРожд = textBoxДатаРожд.Text;
            string новыйКодСотрудника = textBoxКод_сотрудника.Text;

            // Проверка на правильный формат даты для "новаяДатаРожд"
            if (!DateTime.TryParse(новаяДатаРожд, out DateTime датаРожд))
            {
                MessageBox.Show("Значение для 'Дата рождения' должно быть в правильном формате даты.");
                return;
            }

            string query = "UPDATE Сотрудники SET ФИО = @НовоеФИО, Должность = @НоваяДолжность, Отдел = @НовыйОтдел, Контактный_телефон = @НовыйКонтактныйТелефон, Дата_рожд = @НоваяДатаРожд WHERE Код_Сотрудника = @НовыйКодСотрудника";

            using (OleDbConnection dbConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=komandirovki.mdb"))
            {
                try
                {
                    dbConnection.Open();
                    using (OleDbCommand command = new OleDbCommand(query, dbConnection))
                    {
                        command.Parameters.AddWithValue("@НовоеФИО", новоеФИО);
                        command.Parameters.AddWithValue("@НоваяДолжность", новаяДолжность);
                        command.Parameters.AddWithValue("@НовыйОтдел", новыйОтдел);
                        command.Parameters.AddWithValue("@НовыйКонтактныйТелефон", новыйКонтактныйТелефон);
                        command.Parameters.AddWithValue("@НоваяДатаРожд", датаРожд);
                        command.Parameters.AddWithValue("@НовыйКодСотрудника", новыйКодСотрудника);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись обновлена успешно!");
                            DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить запись. Проверьте Код Сотрудника.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
                }
            }
        }
    }
    }


