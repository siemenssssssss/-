﻿using KULSOVAYA.Controller;
using System;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Linq;

namespace KULSOVAYA
{
    public partial class Form1 : Form
    {
        private Query controller;
        private BindingSource bindingSource1 = new BindingSource();
        private OleDbConnection connection;
        private int mode = 0;
        private int n;

        public Form1()
        {
            InitializeComponent();

            controller = new Query();
            connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=komandirovki.mdb");
            try
            {
                connection.Open();

                // Загрузка данных в comboBox3
                DataTable dtSotrudniki = controller.GetSotrudniki();
                if (dtSotrudniki != null)
                {
                    comboBox3.DataSource = dtSotrudniki;
                    comboBox3.DisplayMember = "ФИО";
                    comboBox3.ValueMember = "Код_Сотрудника";
                }

                // Инициализация DataGridView
                dataGridView1.DataSource = controller.GetData("КомандировкиЗапрос");
                dataGridView2.DataSource = controller.GetData("Командировки"); // Загрузка данных в DataGridView2

                // Загрузка данных в TreeView (уникальные отделы)
                TreeNode rootNode = new TreeNode("Название отделов");
                if (komandirovkiDataSet1?.Сотрудники != null)
                {
                    var uniqueDepartments = komandirovkiDataSet1.Сотрудники.AsEnumerable()
                        .Select(row => row.Field<string>("Отдел"))
                        .Where(department => !string.IsNullOrEmpty(department))
                        .Distinct()
                        .OrderBy(department => department);

                    foreach (string department in uniqueDepartments)
                    {
                        rootNode.Nodes.Add(new TreeNode(department));
                    }
                }
                treeView1.Nodes.Add(rootNode);
                treeView1.ExpandAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при инициализации формы: " + ex.Message);
            }
        }


        private void button7_Click(object sender, EventArgs e) // Фильтрация
        {
            DataTable dt = dataGridView1.DataSource as DataTable;
            if (dt == null)
            {
                MessageBox.Show("DataSource is not a DataTable.");
                return;
            }

            string fioFilter = textBox12.Text;
            string отделFilter = textBox11.Text; // Теперь это фильтр по Названию отдела
            string должностьFilter = textBox10.Text; // Теперь это фильтр по Региону

            string filterExpression = "";

            if (checkBox7.Checked && !string.IsNullOrEmpty(fioFilter))
            {
                filterExpression += $"[ФИО] LIKE '%{fioFilter}%'";
            }

            // Фильтрация по Названию отдела
            if (checkBox6.Checked && !string.IsNullOrEmpty(отделFilter))
            {
                if (!string.IsNullOrEmpty(filterExpression))
                {
                    filterExpression += " AND ";
                }
                filterExpression += $"[Название] LIKE '%{отделFilter}%'"; // Фильтруем по Названию
            }


            // Фильтрация по Региону
            if (checkBox5.Checked && !string.IsNullOrEmpty(должностьFilter))
            {
                if (!string.IsNullOrEmpty(filterExpression))
                {
                    filterExpression += " AND ";
                }
                filterExpression += $"[Регион] LIKE '%{должностьFilter}%'"; // Фильтруем по Региону
            }


            // Фильтрация по дате (только если checkBox4 отмечен)
            if (checkBox4.Checked)
            {
                DateTime startDate;
                DateTime endDate;
                if (!DateTime.TryParse(textBox9.Text, out startDate) || !DateTime.TryParse(textBox8.Text, out endDate))
                {
                    MessageBox.Show("Введите корректные даты.");
                    checkBox4.Checked = false;
                    return;
                }
                if (startDate > endDate)
                {
                    MessageBox.Show("Начальная дата не может быть больше конечной.");
                    checkBox4.Checked = false;
                    return;
                }
                if (!string.IsNullOrEmpty(filterExpression))
                {
                    filterExpression += " AND ";
                }
                filterExpression += $"[Дата_начала] >= #{startDate.ToShortDateString()}# AND [Дата_окончания] <= #{endDate.ToShortDateString()}#";
            }

            // Применение фильтра
            try
            {
                (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = filterExpression;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при фильтрации: {ex.Message}");
            }




            bindingSource1.DataSource = dt;
            dataGridView1.DataSource = bindingSource1;

            bindingSource1.Filter = filterExpression;

            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Rows[0].Selected = true;
            }
        }



        private void button1_Click_1(object sender, EventArgs e) // Добавление записи
        {
            try
            {
                int kodSotrudnika = (int)comboBox3.SelectedValue;
                string celPoezdki = textBox1.Text;

                if (!int.TryParse(textBox3.Text, out int mestoNaznacheniya))
                {
                    MessageBox.Show("Некорректное значение для 'Место назначения'. Введите число.");
                    return;
                }

                if (!decimal.TryParse(textBox2.Text, out decimal predpolagaemyeRashody))
                {
                    MessageBox.Show("Некорректное значение для 'Предполагаемые расходы'. Введите число.");
                    return;
                }

                // Получаем значения даты начала и окончания
                DateTime dataNachala;
                DateTime dataOkonchaniya;

                if (!DateTime.TryParse(dateTimePicker1.Text, out dataNachala)) // textBox4 для даты начала
                {
                    MessageBox.Show("Некорректный формат даты начала.");
                    return;
                }

                if (!DateTime.TryParse(dateTimePicker2.Text, out dataOkonchaniya)) // textBox5 для даты окончания
                {
                    MessageBox.Show("Некорректный формат даты окончания.");
                    return;
                }

                // Передаем dataGridView2 в метод Add
                controller.Add( kodSotrudnika, celPoezdki,  mestoNaznacheniya,  predpolagaemyeRashody, dataNachala,dataOkonchaniya,dataGridView2);

                MessageBox.Show("Запись добавлена!");
                dataGridView2.DataSource = controller.GetData("КомандировкиЗапрос"); // Обновление dataGridView1
                                                                                     // dataGridView2.DataSource = controller.GetData("Командировки"); // Это уже сделано внутри Add
            }
            catch (OleDbException ex)
            {
                MessageBox.Show("Ошибка базы данных: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка: " + ex.Message);
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\komandirovki.mdb";
                string query = "SELECT * FROM Командировки WHERE Код_Сотрудника = @Код_Сотрудника";

                using (OleDbConnection connection = new OleDbConnection(connectionString))
                using (OleDbCommand command = new OleDbCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Код_Сотрудника", selectedRow.Cells["Код_сотрудника"].Value);
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView2.DataSource = dt;
                    }
                }
            }
            else
            {
                dataGridView2.DataSource = null; // Очищаем DataGridView2, если ничего не выбрано
                MessageBox.Show("Выберите строку в dataGridView1.");
            }
        }


        private void справочникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.Show();
        }


        public DataTable GetData(string tableName)
        {
            try
            {
                string query = $"SELECT * FROM {tableName}"; // SQL запрос для выбора всех данных из таблицы
                using (OleDbDataAdapter adapter = new OleDbDataAdapter(query, connection))
                {
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    return dataTable;
                }
            }
            catch (OleDbException ex)
            {
                throw new Exception("Ошибка при получении данных: " + ex.Message);
            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                mode = 1; // Устанавливаем режим редактирования
                n = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells["Код_командировки"].Value);
                panel1.Visible = true;
                LoadEditData(n);
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования.");
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
            {
               
            }
        }
        private void LoadEditData(int kod_kom)
        {
            try
            {
                // Используем параметризованный запрос
                using (OleDbConnection connection = new OleDbConnection(controller.connectionString))
                using (OleDbCommand command = new OleDbCommand("SELECT * FROM Командировки WHERE Код_командировки = @Код_командировки", connection))
                {
                    command.Parameters.AddWithValue("@Код_командировки", kod_kom);
                    connection.Open();
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            comboBox3.SelectedValue = reader.GetInt32(reader.GetOrdinal("Код_Сотрудника"));
                            dateTimePicker1.Value = reader.GetDateTime(reader.GetOrdinal("Дата_начала"));
                            dateTimePicker2.Value = reader.GetDateTime(reader.GetOrdinal("Дата_окончания"));
                            textBox1.Text = reader.GetString(reader.GetOrdinal("Цель_поездки"));

                            // Проверяем на DBNull перед преобразованием
                            if (!reader.IsDBNull(reader.GetOrdinal("Место_назначения")))
                            {
                                textBox3.Text = reader.GetInt32(reader.GetOrdinal("Место_назначения")).ToString();
                            }
                            else
                            {
                                textBox3.Text = ""; // Или другое значение по умолчанию
                            }

                            if (!reader.IsDBNull(reader.GetOrdinal("Предполагаемые_расходы")))
                            {
                                textBox2.Text = reader.GetDecimal(reader.GetOrdinal("Предполагаемые_расходы")).ToString();
                            }
                            else
                            {
                                textBox2.Text = ""; // Или другое значение по умолчанию
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке данных: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (mode == 0) // Добавление новой записи
                {
                    // ... (ваш код для добавления новой записи)
                }
                else if (mode == 1) // Редактирование существующей записи
                {
                    int kodKom = n; // n содержит Код_командировки редактируемой записи

                    int kodSotrudnika = (int)comboBox3.SelectedValue;
                    DateTime dataNachala = dateTimePicker1.Value;
                    DateTime dataOkonchaniya = dateTimePicker2.Value;
                    string celPoezdki = textBox1.Text;

                    // Безопасное преобразование текста в числа с учетом возможности null
                    int parsedMesto;
                    int? mestoNaznacheniya = int.TryParse(textBox3.Text, out parsedMesto) ? (int?)parsedMesto : null;

                    decimal parsedRashody;
                    decimal? predpolagaemyeRashody = decimal.TryParse(textBox2.Text, out parsedRashody) ? parsedRashody : default(decimal?);


                    // Вызов UpdateQuery с nullable типами
                    controller.UpdateQuery(kodKom, kodSotrudnika, dataNachala, dataOkonchaniya, celPoezdki, mestoNaznacheniya, predpolagaemyeRashody);

                    MessageBox.Show("Изменения сохранены!");
                    dataGridView2.DataSource = controller.GetData("Командировки"); // Обновление DataGridView
                    panel1.Visible = false; // Закрытие панели редактирования
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.ToString()); // Обработка исключений
            }
        }
    }
    }
    

