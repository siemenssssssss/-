﻿namespace KULSOVAYA
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.фИОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Дата_начала = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Дата_окончания = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Код_Сотрудника = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Цель_поездки = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Место_Назначения = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Предполагаемые_расходы = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Название = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Регион = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.командировкиЗапросBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.komandirovkiDataSet11 = new KULSOVAYA.komandirovkiDataSet();
            this.командировкиЗапросBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.командировкиЗапросBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.общаяИнформацияBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.общаяИнформацияBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.общаяИнформацияBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.komandirovkiDataSet = new KULSOVAYA.komandirovkiDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.общаяИнформацияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.общая_информацияTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.Общая_информацияTableAdapter();
            this.komandirovkiDataSet1 = new KULSOVAYA.komandirovkiDataSet();
            this.командировкиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.командировкиTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.КомандировкиTableAdapter();
            this.населенныйпунктBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенный_пунктTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.Населенный_пунктTableAdapter();
            this.расходыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.расходыTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.РасходыTableAdapter();
            this.сотрудникиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.сотрудникиTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.СотрудникиTableAdapter();
            this.komandirovkiDataSet11BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.общая_информацияTableAdapter1 = new KULSOVAYA.komandirovkiDataSetTableAdapters.Общая_информацияTableAdapter();
            this.сотрудникиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.командировкиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.командировкиРасходыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.командировкиРасходыBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.сотрудникиКомандировкиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.общаяИнформацияBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйпунктКомандировкиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.командировкиЗапросTableAdapter = new KULSOVAYA.komandirovkiDataSetTableAdapters.КомандировкиЗапросTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.кодСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Код_Командировки = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.цельпоездкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.местоНазначенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.предполагаемыерасходыDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.командировкиBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.командировкиBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet11BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиРасходыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиРасходыBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиКомандировкиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктКомандировкиBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.фИОDataGridViewTextBoxColumn,
            this.Дата_начала,
            this.Дата_окончания,
            this.Код_Сотрудника,
            this.Цель_поездки,
            this.Место_Назначения,
            this.Предполагаемые_расходы,
            this.Название,
            this.Регион,
            this.dataGridViewTextBoxColumn1});
            this.dataGridView1.DataSource = this.командировкиЗапросBindingSource2;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView1.Location = new System.Drawing.Point(157, 65);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(888, 379);
            this.dataGridView1.TabIndex = 4;
            // 
            // фИОDataGridViewTextBoxColumn
            // 
            this.фИОDataGridViewTextBoxColumn.DataPropertyName = "ФИО";
            this.фИОDataGridViewTextBoxColumn.HeaderText = "ФИО";
            this.фИОDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.фИОDataGridViewTextBoxColumn.Name = "фИОDataGridViewTextBoxColumn";
            this.фИОDataGridViewTextBoxColumn.Width = 125;
            // 
            // Дата_начала
            // 
            this.Дата_начала.DataPropertyName = "Дата_начала";
            this.Дата_начала.HeaderText = "Дата_начала";
            this.Дата_начала.MinimumWidth = 6;
            this.Дата_начала.Name = "Дата_начала";
            this.Дата_начала.Width = 125;
            // 
            // Дата_окончания
            // 
            this.Дата_окончания.DataPropertyName = "Дата_окончания";
            this.Дата_окончания.HeaderText = "Дата_окончания";
            this.Дата_окончания.MinimumWidth = 6;
            this.Дата_окончания.Name = "Дата_окончания";
            this.Дата_окончания.Width = 125;
            // 
            // Код_Сотрудника
            // 
            this.Код_Сотрудника.DataPropertyName = "Код_Сотрудника";
            this.Код_Сотрудника.HeaderText = "Код_Сотрудника";
            this.Код_Сотрудника.MinimumWidth = 6;
            this.Код_Сотрудника.Name = "Код_Сотрудника";
            this.Код_Сотрудника.Width = 125;
            // 
            // Цель_поездки
            // 
            this.Цель_поездки.DataPropertyName = "Цель_поездки";
            this.Цель_поездки.HeaderText = "Цель_поездки";
            this.Цель_поездки.MinimumWidth = 6;
            this.Цель_поездки.Name = "Цель_поездки";
            this.Цель_поездки.Visible = false;
            this.Цель_поездки.Width = 125;
            // 
            // Место_Назначения
            // 
            this.Место_Назначения.DataPropertyName = "Место_Назначения";
            this.Место_Назначения.HeaderText = "Место_Назначения";
            this.Место_Назначения.MinimumWidth = 6;
            this.Место_Назначения.Name = "Место_Назначения";
            this.Место_Назначения.Visible = false;
            this.Место_Назначения.Width = 125;
            // 
            // Предполагаемые_расходы
            // 
            this.Предполагаемые_расходы.DataPropertyName = "Предполагаемые_расходы";
            this.Предполагаемые_расходы.HeaderText = "Предполагаемые_расходы";
            this.Предполагаемые_расходы.MinimumWidth = 6;
            this.Предполагаемые_расходы.Name = "Предполагаемые_расходы";
            this.Предполагаемые_расходы.Visible = false;
            this.Предполагаемые_расходы.Width = 125;
            // 
            // Название
            // 
            this.Название.DataPropertyName = "Название";
            this.Название.HeaderText = "Название";
            this.Название.MinimumWidth = 6;
            this.Название.Name = "Название";
            this.Название.Width = 125;
            // 
            // Регион
            // 
            this.Регион.DataPropertyName = "Регион";
            this.Регион.HeaderText = "Регион";
            this.Регион.MinimumWidth = 6;
            this.Регион.Name = "Регион";
            this.Регион.Width = 125;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Суточные";
            this.dataGridViewTextBoxColumn1.HeaderText = "Суточные";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 125;
            // 
            // командировкиЗапросBindingSource2
            // 
            this.командировкиЗапросBindingSource2.DataMember = "КомандировкиЗапрос";
            this.командировкиЗапросBindingSource2.DataSource = this.komandirovkiDataSet11;
            // 
            // komandirovkiDataSet11
            // 
            this.komandirovkiDataSet11.DataSetName = "komandirovkiDataSet1";
            this.komandirovkiDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // командировкиЗапросBindingSource1
            // 
            this.командировкиЗапросBindingSource1.DataMember = "КомандировкиЗапрос";
            this.командировкиЗапросBindingSource1.DataSource = this.komandirovkiDataSet11;
            // 
            // командировкиЗапросBindingSource
            // 
            this.командировкиЗапросBindingSource.DataMember = "КомандировкиЗапрос";
            this.командировкиЗапросBindingSource.DataSource = this.komandirovkiDataSet11;
            // 
            // общаяИнформацияBindingSource3
            // 
            this.общаяИнформацияBindingSource3.DataMember = "Общая информация";
            this.общаяИнформацияBindingSource3.DataSource = this.komandirovkiDataSet11;
            // 
            // общаяИнформацияBindingSource2
            // 
            this.общаяИнформацияBindingSource2.DataMember = "Общая информация";
            this.общаяИнформацияBindingSource2.DataSource = this.komandirovkiDataSet11;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справочникиToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1531, 28);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            this.справочникиToolStripMenuItem.Size = new System.Drawing.Size(117, 24);
            this.справочникиToolStripMenuItem.Text = "Справочники";
            this.справочникиToolStripMenuItem.Click += new System.EventHandler(this.справочникиToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(0, 65);
            this.treeView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(148, 666);
            this.treeView1.TabIndex = 6;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.BindingSource = this.общаяИнформацияBindingSource1;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 28);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1531, 27);
            this.bindingNavigator1.TabIndex = 7;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // общаяИнформацияBindingSource1
            // 
            this.общаяИнформацияBindingSource1.DataMember = "Общая информация";
            this.общаяИнформацияBindingSource1.DataSource = this.komandirovkiDataSet;
            // 
            // komandirovkiDataSet
            // 
            this.komandirovkiDataSet.DataSetName = "komandirovkiDataSet";
            this.komandirovkiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(49, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // общаяИнформацияBindingSource
            // 
            this.общаяИнформацияBindingSource.DataMember = "Общая информация";
            this.общаяИнформацияBindingSource.DataSource = this.komandirovkiDataSet;
            // 
            // общая_информацияTableAdapter
            // 
            this.общая_информацияTableAdapter.ClearBeforeFill = true;
            // 
            // komandirovkiDataSet1
            // 
            this.komandirovkiDataSet1.DataSetName = "komandirovkiDataSet";
            this.komandirovkiDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // командировкиBindingSource
            // 
            this.командировкиBindingSource.DataMember = "Командировки";
            this.командировкиBindingSource.DataSource = this.komandirovkiDataSet1;
            // 
            // командировкиTableAdapter
            // 
            this.командировкиTableAdapter.ClearBeforeFill = true;
            // 
            // населенныйпунктBindingSource
            // 
            this.населенныйпунктBindingSource.DataMember = "Населенный_пункт";
            this.населенныйпунктBindingSource.DataSource = this.komandirovkiDataSet1;
            // 
            // населенный_пунктTableAdapter
            // 
            this.населенный_пунктTableAdapter.ClearBeforeFill = true;
            // 
            // расходыBindingSource
            // 
            this.расходыBindingSource.DataMember = "Расходы";
            this.расходыBindingSource.DataSource = this.komandirovkiDataSet1;
            // 
            // расходыTableAdapter
            // 
            this.расходыTableAdapter.ClearBeforeFill = true;
            // 
            // сотрудникиBindingSource
            // 
            this.сотрудникиBindingSource.DataMember = "Сотрудники";
            this.сотрудникиBindingSource.DataSource = this.komandirovkiDataSet1;
            // 
            // сотрудникиTableAdapter
            // 
            this.сотрудникиTableAdapter.ClearBeforeFill = true;
            // 
            // komandirovkiDataSet11BindingSource
            // 
            this.komandirovkiDataSet11BindingSource.DataSource = this.komandirovkiDataSet11;
            this.komandirovkiDataSet11BindingSource.Position = 0;
            // 
            // общая_информацияTableAdapter1
            // 
            this.общая_информацияTableAdapter1.ClearBeforeFill = true;
            // 
            // сотрудникиBindingSource1
            // 
            this.сотрудникиBindingSource1.DataMember = "Сотрудники";
            this.сотрудникиBindingSource1.DataSource = this.komandirovkiDataSet11;
            // 
            // командировкиBindingSource1
            // 
            this.командировкиBindingSource1.DataMember = "Командировки";
            this.командировкиBindingSource1.DataSource = this.komandirovkiDataSet11;
            // 
            // командировкиРасходыBindingSource
            // 
            this.командировкиРасходыBindingSource.DataMember = "КомандировкиРасходы";
            this.командировкиРасходыBindingSource.DataSource = this.командировкиBindingSource;
            // 
            // командировкиРасходыBindingSource1
            // 
            this.командировкиРасходыBindingSource1.DataMember = "КомандировкиРасходы";
            this.командировкиРасходыBindingSource1.DataSource = this.командировкиBindingSource;
            // 
            // сотрудникиКомандировкиBindingSource
            // 
            this.сотрудникиКомандировкиBindingSource.DataMember = "СотрудникиКомандировки";
            this.сотрудникиКомандировкиBindingSource.DataSource = this.сотрудникиBindingSource;
            // 
            // общаяИнформацияBindingSource4
            // 
            this.общаяИнформацияBindingSource4.DataMember = "Общая информация";
            this.общаяИнформацияBindingSource4.DataSource = this.komandirovkiDataSet11;
            // 
            // населенныйпунктКомандировкиBindingSource
            // 
            this.населенныйпунктКомандировкиBindingSource.DataMember = "Населенный_пунктКомандировки";
            this.населенныйпунктКомандировкиBindingSource.DataSource = this.населенныйпунктBindingSource;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.button7);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.textBox10);
            this.panel4.Controls.Add(this.textBox11);
            this.panel4.Controls.Add(this.textBox12);
            this.panel4.Controls.Add(this.checkBox4);
            this.panel4.Controls.Add(this.checkBox5);
            this.panel4.Controls.Add(this.checkBox6);
            this.panel4.Controls.Add(this.checkBox7);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Location = new System.Drawing.Point(1216, 65);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(315, 309);
            this.panel4.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(131, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 20);
            this.label9.TabIndex = 14;
            this.label9.Text = "-";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.Location = new System.Drawing.Point(101, 267);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 33);
            this.button7.TabIndex = 13;
            this.button7.Text = "Поиск";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(152, 239);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(136, 22);
            this.textBox8.TabIndex = 12;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(0, 239);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(125, 22);
            this.textBox9.TabIndex = 11;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(128, 140);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(111, 22);
            this.textBox10.TabIndex = 10;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(103, 92);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(151, 22);
            this.textBox11.TabIndex = 9;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(92, 49);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(151, 22);
            this.textBox12.TabIndex = 8;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox4.Location = new System.Drawing.Point(0, 194);
            this.checkBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(164, 22);
            this.checkBox4.TabIndex = 7;
            this.checkBox4.Text = "Интервал времени:";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox5.Location = new System.Drawing.Point(0, 140);
            this.checkBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(79, 22);
            this.checkBox5.TabIndex = 7;
            this.checkBox5.Text = "Регион";
            this.checkBox5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox6.Location = new System.Drawing.Point(0, 94);
            this.checkBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(97, 22);
            this.checkBox6.TabIndex = 7;
            this.checkBox6.Text = "Название";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox7.Location = new System.Drawing.Point(0, 49);
            this.checkBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(66, 22);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.Text = "ФИО";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(109, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 18);
            this.label10.TabIndex = 0;
            this.label10.Text = "Критерии:";
            // 
            // командировкиЗапросTableAdapter
            // 
            this.командировкиЗапросTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодСотрудникаDataGridViewTextBoxColumn,
            this.Код_Командировки,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.цельпоездкиDataGridViewTextBoxColumn,
            this.местоНазначенияDataGridViewTextBoxColumn,
            this.предполагаемыерасходыDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.командировкиBindingSource2;
            this.dataGridView2.Location = new System.Drawing.Point(154, 472);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(891, 258);
            this.dataGridView2.TabIndex = 22;
            // 
            // кодСотрудникаDataGridViewTextBoxColumn
            // 
            this.кодСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Код_Сотрудника";
            this.кодСотрудникаDataGridViewTextBoxColumn.HeaderText = "Код_Сотрудника";
            this.кодСотрудникаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодСотрудникаDataGridViewTextBoxColumn.Name = "кодСотрудникаDataGridViewTextBoxColumn";
            this.кодСотрудникаDataGridViewTextBoxColumn.Width = 125;
            // 
            // Код_Командировки
            // 
            this.Код_Командировки.DataPropertyName = "Код_Командировки";
            this.Код_Командировки.HeaderText = "Код_Командировки";
            this.Код_Командировки.MinimumWidth = 6;
            this.Код_Командировки.Name = "Код_Командировки";
            this.Код_Командировки.Visible = false;
            this.Код_Командировки.Width = 125;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Дата_начала";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата_начала";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Дата_окончания";
            this.dataGridViewTextBoxColumn3.HeaderText = "Дата_окончания";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 6;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 125;
            // 
            // цельпоездкиDataGridViewTextBoxColumn
            // 
            this.цельпоездкиDataGridViewTextBoxColumn.DataPropertyName = "Цель_поездки";
            this.цельпоездкиDataGridViewTextBoxColumn.HeaderText = "Цель_поездки";
            this.цельпоездкиDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.цельпоездкиDataGridViewTextBoxColumn.Name = "цельпоездкиDataGridViewTextBoxColumn";
            this.цельпоездкиDataGridViewTextBoxColumn.Width = 125;
            // 
            // местоНазначенияDataGridViewTextBoxColumn
            // 
            this.местоНазначенияDataGridViewTextBoxColumn.DataPropertyName = "Место_Назначения";
            this.местоНазначенияDataGridViewTextBoxColumn.HeaderText = "Место_Назначения";
            this.местоНазначенияDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.местоНазначенияDataGridViewTextBoxColumn.Name = "местоНазначенияDataGridViewTextBoxColumn";
            this.местоНазначенияDataGridViewTextBoxColumn.Width = 125;
            // 
            // предполагаемыерасходыDataGridViewTextBoxColumn
            // 
            this.предполагаемыерасходыDataGridViewTextBoxColumn.DataPropertyName = "Предполагаемые_расходы";
            this.предполагаемыерасходыDataGridViewTextBoxColumn.HeaderText = "Предполагаемые_расходы";
            this.предполагаемыерасходыDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.предполагаемыерасходыDataGridViewTextBoxColumn.Name = "предполагаемыерасходыDataGridViewTextBoxColumn";
            this.предполагаемыерасходыDataGridViewTextBoxColumn.Width = 125;
            // 
            // командировкиBindingSource2
            // 
            this.командировкиBindingSource2.DataMember = "Командировки";
            this.командировкиBindingSource2.DataSource = this.komandirovkiDataSet11;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Location = new System.Drawing.Point(154, 444);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(224, 26);
            this.button3.TabIndex = 23;
            this.button3.Text = "Отобразить командировку✔️";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.Location = new System.Drawing.Point(384, 444);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(306, 26);
            this.button6.TabIndex = 24;
            this.button6.Text = "Добавить/редактировать";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.dateTimePicker2);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.comboBox3);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(1051, 451);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(480, 288);
            this.panel1.TabIndex = 25;
            this.panel1.Visible = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(174, 232);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 48;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(145, 195);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker1.TabIndex = 47;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(13, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 20);
            this.label6.TabIndex = 46;
            this.label6.Text = "Дата_окончания:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(13, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(126, 20);
            this.label5.TabIndex = 45;
            this.label5.Text = "Дата_начала:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Info;
            this.button2.Location = new System.Drawing.Point(362, 257);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 31);
            this.button2.TabIndex = 43;
            this.button2.Text = "Редактировать";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Info;
            this.button1.Location = new System.Drawing.Point(0, 257);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 31);
            this.button1.TabIndex = 42;
            this.button1.Text = "Ok";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(29, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(429, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "Добавление/редактирование командировки:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(275, 160);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(109, 22);
            this.textBox2.TabIndex = 40;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(191, 92);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(150, 22);
            this.textBox1.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(241, 20);
            this.label3.TabIndex = 38;
            this.label3.Text = "Предполагаемые_расходы:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(13, 127);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(178, 20);
            this.label11.TabIndex = 33;
            this.label11.Text = "Место_Назначения:";
            // 
            // comboBox3
            // 
            this.comboBox3.DisplayMember = "Название";
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(191, 56);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(152, 24);
            this.comboBox3.TabIndex = 37;
            this.comboBox3.ValueMember = "КодМероприятия";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(210, 126);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(150, 22);
            this.textBox3.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(13, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(152, 20);
            this.label8.TabIndex = 30;
            this.label8.Text = "Код_Сотрудника";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "Цель_поездки:";
            // 
            // командировкиBindingSource3
            // 
            this.командировкиBindingSource3.DataMember = "Командировки";
            this.командировкиBindingSource3.DataSource = this.komandirovkiDataSet11;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Info;
            this.button4.Location = new System.Drawing.Point(174, 257);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 31);
            this.button4.TabIndex = 49;
            this.button4.Text = "Сохранить";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(696, 444);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(306, 26);
            this.button5.TabIndex = 26;
            this.button5.Text = "Обновить DataGridView";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1531, 742);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "FormMain";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиЗапросBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.komandirovkiDataSet11BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиРасходыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиРасходыBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиКомандировкиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.общаяИнформацияBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.населенныйпунктКомандировкиBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.командировкиBindingSource3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private komandirovkiDataSet komandirovkiDataSet;
        private System.Windows.Forms.BindingSource общаяИнформацияBindingSource;
        private komandirovkiDataSetTableAdapters.Общая_информацияTableAdapter общая_информацияTableAdapter;
        private System.Windows.Forms.BindingSource общаяИнформацияBindingSource1;
        private System.Windows.Forms.TreeView treeView1;
        private komandirovkiDataSet komandirovkiDataSet1;
        private System.Windows.Forms.BindingSource командировкиBindingSource;
        private komandirovkiDataSetTableAdapters.КомандировкиTableAdapter командировкиTableAdapter;
        private System.Windows.Forms.BindingSource населенныйпунктBindingSource;
        private komandirovkiDataSetTableAdapters.Населенный_пунктTableAdapter населенный_пунктTableAdapter;
        private System.Windows.Forms.BindingSource расходыBindingSource;
        private komandirovkiDataSetTableAdapters.РасходыTableAdapter расходыTableAdapter;
        private System.Windows.Forms.BindingSource сотрудникиBindingSource;
        private komandirovkiDataSetTableAdapters.СотрудникиTableAdapter сотрудникиTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.BindingSource komandirovkiDataSet11BindingSource;
        private komandirovkiDataSet komandirovkiDataSet11;
        private System.Windows.Forms.BindingSource общаяИнформацияBindingSource2;
        private komandirovkiDataSetTableAdapters.Общая_информацияTableAdapter общая_информацияTableAdapter1;
        private System.Windows.Forms.BindingSource сотрудникиBindingSource1;
        private System.Windows.Forms.BindingSource командировкиBindingSource1;
        private System.Windows.Forms.BindingSource командировкиРасходыBindingSource;
        private System.Windows.Forms.BindingSource общаяИнформацияBindingSource3;
        private System.Windows.Forms.BindingSource командировкиРасходыBindingSource1;
        private System.Windows.Forms.BindingSource сотрудникиКомандировкиBindingSource;
        private System.Windows.Forms.BindingSource общаяИнформацияBindingSource4;
        private System.Windows.Forms.BindingSource населенныйпунктКомандировкиBindingSource;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.BindingSource командировкиЗапросBindingSource;
        private komandirovkiDataSetTableAdapters.КомандировкиЗапросTableAdapter командировкиЗапросTableAdapter;
        private System.Windows.Forms.BindingSource командировкиЗапросBindingSource1;
        private System.Windows.Forms.BindingSource командировкиЗапросBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource командировкиBindingSource2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource командировкиBindingSource3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Дата_начала;
        private System.Windows.Forms.DataGridViewTextBoxColumn Дата_окончания;
        private System.Windows.Forms.DataGridViewTextBoxColumn Код_Сотрудника;
        private System.Windows.Forms.DataGridViewTextBoxColumn Цель_поездки;
        private System.Windows.Forms.DataGridViewTextBoxColumn Место_Назначения;
        private System.Windows.Forms.DataGridViewTextBoxColumn Предполагаемые_расходы;
        private System.Windows.Forms.DataGridViewTextBoxColumn Название;
        private System.Windows.Forms.DataGridViewTextBoxColumn Регион;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Код_Командировки;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn цельпоездкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn местоНазначенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn предполагаемыерасходыDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}

